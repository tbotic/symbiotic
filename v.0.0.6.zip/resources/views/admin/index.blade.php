@extends('layouts.app')

@section('header')
@include('layouts.header-admin')
@endsection


@section('content')

@endsection


@section('footer')
@include('layouts.footer-admin')
@endsection
