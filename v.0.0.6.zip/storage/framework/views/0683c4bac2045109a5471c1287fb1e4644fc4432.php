

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="banner-container">
        <div class="container banner-area">
            <div class="row h-100">
                <div class="col-12 my-auto">
                    <div class="banner-title-area">
                        <h2 class="banner-title">Product</h2>
                        <p class="banner-subtitle">Home <span><i class="fa fa-angle-right"></i></span> Product</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-section">
        <div class="container">
            <div class="row two-service-section">
                <div class="col-12 col-md-6">

                    <div id="custCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
                        
                        <div class="carousel-inner">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>"> 
                                <img src="<?php echo e(asset($image->path)); ?>" class="img-responsive" alt=""> 
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <ol class="carousel-indicators list-inline">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-inline-item <?php echo e($loop->index ? 'active' : ''); ?>"> <a id="carousel-selector-0" class="selected" data-slide-to="<?php echo e($loop->index); ?>" data-target="#custCarousel"> <img src="<?php echo e(asset($image->path)); ?>" class="img-responsive"> </a> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>

                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="row no-gutters">
                        <div class="col-12">
                            <div class="main-section-title-side">
                                <h2 class="heading"><?php echo e($product->title); ?></h2>
                                <h5 class="heading-sm"><?php echo e($product->subtitle); ?></h5>
                            </div>
                        </div>
                        <div class="col-12">
                            <p><?php echo e($product->excerpt); ?></p>
                        </div>
                        <form id="formAddToCart" action="<?php echo e(route('addToCart', ['id' => $product->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <div class="col-12 mb-4">
                                <div class="row align-items-center">
                                    <div class="col-4">
                                        <input name="productQty" class="form-control" type="number" value="1" min="1" oninput="this.value = !!this.value && Math.abs(this.value) >= 1 ? Math.abs(this.value) : null">
                                    </div>
                                    <div class="col-8">
                                        <h5 class="product-price">from €<?php echo e($product->price); ?></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="submit" class="btn btn-pink">Add To Cart</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="product-info-nav" class="col-12 my-5">
                    <ul class="nav nav-tabs mb-3" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">Description</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="additionalInfo-tab" data-toggle="tab" href="#additionalInfo" role="tab" aria-controls="additionalInfo" aria-selected="false">Additional Info</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                            <h4 class="heading-sm">Description</h4>
                            <p><?php echo $product->description; ?></p>
                        </div>
                        <div class="tab-pane fade" id="additionalInfo" role="tabpanel" aria-labelledby="additionalInfo-tab">
                            <h4 class="heading-sm">Additional Info</h4>
                            <p><?php echo $product->addInfo; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.6\resources\views/shop/product.blade.php ENDPATH**/ ?>