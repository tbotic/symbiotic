<footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-3">
                        <h3 class="footer-heading">SymbIoTic</h3>
                        <p class="text-justify">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem consequuntur, quos id perferendis.</p>
                    </div>
                    <div class="col-12 col-md-3">
                        <h4 class="footer-heading">LINKS</h4>
                        <ul class="foot-ul">
                            <li><i class="fa fa-angle-right"></i> <a href="privacy-policy.php" class="scrollto">Home</a></li>
                            <li><i class="fa fa-angle-right"></i> <a href="#myCarousel" class="scrollto">Services</a></li>
                            <li><i class="fa fa-angle-right"></i> <a href="#reference" class="scrollto">Shop</a></li>
                            <li><i class="fa fa-angle-right"></i> <a href="privacy-policy.php" class="scrollto">Blog</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-3">
                        <h4 class="footer-heading">SUPPORT</h4>
                        <ul class="foot-ul">
                            <li><i class="fa fa-angle-right"></i> <a href="privacy-policy.php" class="scrollto">Contact Us</a></li>
                            <li><i class="fa fa-angle-right"></i> <a href="privacy-policy.php" class="scrollto">About Us</a></li>
                            <li><i class="fa fa-angle-right"></i> <a href="#myCarousel" class="scrollto">Terms of Use</a></li>
                            <li><i class="fa fa-angle-right"></i> <a href="#reference" class="scrollto">Privacy Policy</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-3">
                        <h4 class="footer-heading">FOLLOW US</h4>
                        <ul class="foot-info">
                            <li><i class="fa fa-phone"></i>+385 (0) 097 613 2503</li>
                            <li><i class="fa fa-envelope-o"></i>info@symbiotic.com</li>
                        </ul>
                        <div class="foot-divs">
                            <i class="fa fa-linkedin"></i>
                            <i class="fa fa-facebook"></i>
                            <i class="fa fa-instagram"></i>
                            <i class="fa fa-youtube"></i>
                        </div>
                    </div>
                </div>
            </div>

        </footer><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.6\resources\views/layouts/footer-admin.blade.php ENDPATH**/ ?>