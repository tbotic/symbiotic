

<?php $__env->startSection('content'); ?>
<div>
    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-4">
                    <h2>Edit Item</h2>
                </div>
                <div class="col-12">
                    <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-title" name="title" placeholder="Product Title" value="<?php echo e($product->title); ?>">
                        </div>
                        <div id="form-group" class="form-row">
                            <div class="col-md-4">
                                <img src="<?php echo e(asset($product->featuredImage()->path)); ?>" id="featured-thumb-image" class="col-md-4 img-responsive">
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <button type="button" id="add-featured" class="btn btn-sm btn-secondary">Change Featured Image</button>
                            <input type="file" class="d-none" id="featured-image-input" name="featured-image" onChange="document.getElementById('featured-thumb-image').src=window.URL.createObjectURL(this.files[0])">
                        </div>
                        <div id="thumbs" class="form-row">
                            <?php if($product->images->count()): ?>
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($image->featured === 0): ?>
                                            <div class="form-group thumb-product-wrapper col-md-4">
                                                <img id="thumb-image " src="<?php echo e(asset($image->path)); ?>" class="img-responsive">
                                                <a href="<?php echo e(route('imageDestroy', $image->id)); ?>" class="btn btn-danger btn-sm remove-img" type="button" title="delete"><span class="fa fa-times fa-lg"></span></a>
                                            </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="button" id="add" class="btn btn-sm btn-light">Add More Images</button>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-subtitle" name="subtitle" placeholder="Product Subtitle" value="<?php echo e($product->subtitle); ?>">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-excerpt" name="excerpt" placeholder="Excerpt" rows="3"><?php echo e($product->excerpt); ?></textarea>
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-price" name="price" placeholder="Product Price" value="<?php echo e($product->price); ?>">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-description" name="description" placeholder="Post Description" rows="20"><?php echo e($product->description); ?></textarea>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['addInfo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-addInfo" name="addInfo" placeholder="Post Additional Information" rows="20"><?php echo e($product->addInfo); ?></textarea>
                        </div>
                        <div class="form-group">
                            <input type="file" class="form-control-img <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-image" name="image">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Publish</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<script>

var i = 0;

$("#add").click(function(){
    i++;
    $("#thumbs").append('<div id="#product-wrapper'+ i +'" class="form-group col-md-4 thumb-product-wrapper"><img id="thumb-image'+ i +'" class="img-responsive"><a class="btn btn-danger btn-sm remove-img" type="button" onclick="this.parentElement.remove();"><span class="fa fa-times fa-lg"></span></a><input type="file" class="d-none" id="product-image'+ i +'" name="image'+ i +'" onchange=" document.getElementById(&apos;thumb-image'+i+'&apos;).src = window.URL.createObjectURL(this.files[0]) "></div>');
    $('#product-image'+ i +'').click();
});

$("#add-featured").click(function(){
    $('#featured-image-input').click();
});

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.3\resources\views/admin/shop/editProduct.blade.php ENDPATH**/ ?>