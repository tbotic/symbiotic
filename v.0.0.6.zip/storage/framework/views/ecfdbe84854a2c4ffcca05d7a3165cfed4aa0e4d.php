

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="banner-container">
        <div class="container banner-area">
            <div class="row h-100">
                <div class="col-12 my-auto">
                    <div class="banner-title-area">
                        <h2 class="banner-title">Shop</h2>
                        <p class="banner-subtitle">Home <span><i class="fa fa-angle-right"></i></span> Shop</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-section-title">
                        <p class="subheading">OUR SHOP</p>
                        <h2 class="heading">Welcome to our product <span>Catalog</span></h2>
                        <p class="mt-4">Add products that interests you to the cart and send us an inquiry.<br><b>We'll contact you in short notice with an offer.</b></p>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row">
                    <?php if($products->count()): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-sm-6 col-md-4">
                            <a href="<?php echo e(route('products.show', $product->id)); ?>">
                                <div class="mission-box">
                                    <div class="shop-img-wrapper" style="background-image:url(<?php echo e(asset($product->featuredImage()->path)); ?>)"></div>
                                    <div class="mission-box-caption">
                                        <h6><?php echo e($product->title); ?></h6>
                                        <p>from €<?php echo e($product->price); ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($products->links()); ?>

                    <?php else: ?>
                        <div class="col-12">
                            <p class="text-center">There are no listed products at this moment.</p>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.6\resources\views/shop/index.blade.php ENDPATH**/ ?>