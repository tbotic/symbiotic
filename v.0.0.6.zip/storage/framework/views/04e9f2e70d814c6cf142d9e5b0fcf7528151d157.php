

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="banner-container">
        <div class="container banner-area">
            <div class="row h-100">
                <div class="col-12 my-auto">
                    <div class="banner-title-area">
                        <h2 class="banner-title">Cart</h2>
                        <p class="banner-subtitle">Home <span><i class="fa fa-angle-right"></i></span> Cart</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-section">
        <div class="container">
            <?php if(Session::has('cart')): ?>
                <div class="d-none d-md-flex row cart-head">
                    <div class="col-1">
                    </div>
                    <div class="col-6 cart-title">
                        Product
                    </div>
                    <div class="col-2">
                        Quantity
                    </div>
                    <div class="col-2">
                        Price
                    </div>
                    <div class="col-1">
                    </div>
                </div>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row cart-body">
                        <div class="col-1 d-none d-md-flex">
                            <img src="<?php echo e($product['item']->featuredImage()->path); ?>" alt="" class="img-query-table">
                        </div>
                        <div class="col-12 col-md-6 cart-title">
                            <?php echo e($product['item']['title']); ?>

                        </div>
                        <div class="col-5 col-md-2">
                            <span><a href="<?php echo e(route('reduceByOne', ['id' => $product['item']['id']])); ?>" class="mr-3" type="button" title="reduce"><i class="fa fa-minus"></i></a></span>
                                <?php echo e($product['qty']); ?>

                            <span><a href="<?php echo e(route('addByOne', ['id' => $product['item']['id']])); ?>" class="ml-3" type="button" title="add"><i class="fa fa-plus"></i></a></span>
                        </div>
                        <div class="col-5 col-md-2">
                            from €<?php echo e($product['price']); ?>

                        </div>
                        <div class="col-2 col-md-1">
                        <a href="<?php echo e(route('removeItem', ['id' => $product['item']['id']])); ?>" class="btn btn-outline-danger" type="button" title="delete"><i class="fa fa-trash"></i></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row cart-footer">
                    <div class="d-none d-md-flex col-1">
                    </div>
                    <div class="d-none d-md-flex col-md-6 cart-title">
                        Total
                    </div>
                    <div class="col-5 col-md-2">
                        <?php echo e($totalQty); ?>

                    </div>
                    <div class="col-5 col-md-2">
                        from €<?php echo e($totalPrice); ?>

                    </div>
                    <div class="col-2 col-md-1">
                    </div>
                </div>
            <?php else: ?>
            <div class="row">
                <div class="col-12">
                    <h5 class="text-center my-5">There are no items in cart yet.</h5>
                </div>
            </div>
            <?php endif; ?>
            <div class="row mt-5">
                <div class="col-12 d-flex justify-content-between">
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-white">Add More Items</a>
                    <a href="<?php echo e(route('checkout')); ?>" class="btn btn-pink">Proceed</a>
                </div>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.5\resources\views/shop/cart.blade.php ENDPATH**/ ?>