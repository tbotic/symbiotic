

<?php $__env->startSection('content'); ?>
<div class="admin-content-padding">
    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-4 d-flex justify-content-between">
                    <h2>Admin Dashboard</h2>
                </div>
                <?php if($message = Session::get('flash')): ?>
                <div class="col-12">
                    <div class="alert alert-success">
                        <?php echo e($message); ?>

                    </div>
                </div>
                <?php endif; ?>
                <div class="col-12 mb-4 d-flex justify-content-between">
                    <h5>Shop Overview</h5>
                </div>
                <div class="col-12">
                    <table class="table table-hover admin-blog-table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">Item</th>
                                <th scope="col">Price</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($products->count()): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('products.show', $product->id)); ?>"><?php echo e($product->title); ?></a></td>
                                    <td><?php echo e($product->price); ?></td>
                                    <td class="pull-right">
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-light mr-1" title="edit"><i class="fa fa-edit"></i></a>
                                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger" type="submit" title="delete"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td class="title-admin-blog-table">
                                        There are no items yet
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($products->links()); ?>

                </div>
                <div class="col-12 mb-4 d-flex justify-content-between">
                    <h5>Blog Overview</h5>
                </div>
                <div class="col-12">
                    <table class="table table-hover admin-blog-table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">Title</th>
                                <th scope="col" class="d-none d-md-table-cell">Author</th>
                                <th scope="col" class="d-none d-md-table-cell">Date</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($posts->count()): ?>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="title-admin-blog-table <?php echo e($post->featured ? 'font-weight-bold' : ''); ?>"><a href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($post->user->name); ?></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($post->created_at->format('d.m.Y.')); ?></td>
                                        <td class="pull-right">
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-light mr-1" title="edit"><i class="fa fa-edit"></i></a>
                                                <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger" type="submit" title="delete"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td class="title-admin-blog-table">
                                        There are no posts
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.5\resources\views/admin/home.blade.php ENDPATH**/ ?>