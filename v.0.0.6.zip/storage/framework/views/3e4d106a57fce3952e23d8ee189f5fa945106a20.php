        
        <?php if(session()->has('newsletterPopup')): ?>
        <?php else: ?>
        <!-- Modal -->
        <div id="newsletter-modal" class="modal fade show" role="dialog" data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class='modal-header'>
                        <h3 class='col-12 modal-title text-center'>
                            Subscribe to Newsletter
                        </h3>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="row d-flex align-items-center">
                                <div class="col-12 col-lg-5">
                                    <div class="mail-modal-img">
                                        <img src="<?php echo e(asset('img/mail-modal.png')); ?>" class="img-responsive" alt="">
                                    </div>
                                </div>
                                <div class="col-12 col-lg-7">
                                    <p>Subscribe to be the first to know about all the news and promotion activities from Symbiotic.</p>
                                    <p><b>We quarantee you no spam mail from us.</b></p>
                                    <form class="form mt-4" method="POST" action="<?php echo e(route('newsletterConfirm')); ?>">
                                        <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <input type="email" name="email" class="form-control" placeholder="Your Email" required>
                                            </div>
                                            <div class="form-group d-flex justify-content-between">
                                                <button type="submit" value="accept" name="submitbutton" class="btn btn-pink">Receive Newsletter</button>
                                                <button type="button" value="deny" name="submitbutton" id="deny" class="btn btn-white">No, thanks</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="eu-header header bg-light">
            <div class="container <?php echo e(Route::is('home') ? 'd-block' : 'd-none'); ?> py-2">
                    <div class="row">
                        <div class="col-12">
                            <a href="<?php echo e(route('euFunding')); ?>" class="eu-header-content d-flex justify-start align-items-center">
                                <img src="img/eu-flag.png" class="eu-flag" alt="">
                                <p><span>European Union - Together to EU Funds</span><br> The project was co-financed by the European Regional Development Fund</p>
                            </a>
                        </div>
                    </div>
            </div>
        </div>
        <nav id="main-nav" class="navbar navbar-expand-md navbar-dark bg-transparent sticky-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <?php echo e(config('app.name', 'SymbIoTic')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto my-auto">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('solutions') ? 'active' : ''); ?>" href="<?php echo e(route('solutions')); ?>">Solutions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('products.index') ? 'active' : ''); ?>" href="<?php echo e(route('products.index')); ?>">Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('posts.index') ? 'active' : ''); ?>" href="<?php echo e(route('posts.index')); ?>">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('aboutUs') ? 'active' : ''); ?>" href="<?php echo e(route('aboutUs')); ?>">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('contactUs') ? 'active' : ''); ?>" href="<?php echo e(route('contactUs')); ?>">Contact Us</a>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto my-auto">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::is('cart') ? 'active' : ''); ?> d-flex align-items-center" href="<?php echo e(route('cart')); ?>">
                                <span class="fa fa-shopping-cart fa-2x mr-2"></span>
                                Cart
                                <span class="ml-2"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : ''); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.4\resources\views/layouts/header.blade.php ENDPATH**/ ?>