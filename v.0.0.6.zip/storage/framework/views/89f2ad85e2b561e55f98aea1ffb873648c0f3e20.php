

<?php $__env->startSection('content'); ?>
<div class="admin-content-padding">
    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-4">
                    <h2>Add New Post</h2>
                </div>
                <div class="col-12">
                    <form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="post-title" name="title" aria-describedby="post title" placeholder="Post Title" value="<?php echo e(old('title')); ?>">
                        </div>
                        <div id="form-group" class="form-row">
                            <div class="col-md-4">
                                <img id="featured-thumb-image" class="col-md-4 img-responsive">
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <button type="button" id="add-featured" class="btn btn-sm btn-secondary">Set Featured Image</button>
                            <input type="file" class="d-none" id="post-image" name="image" onChange="document.getElementById('featured-thumb-image').src=window.URL.createObjectURL(this.files[0])">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="post-excerpt" name="excerpt" placeholder="Excerpt" rows="3"><?php echo e(old('excerpt')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control ckeditor <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="post-body" name="body" placeholder="Post Text" rows="20"><?php echo e(old('body')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="post-featured" name="featured">
                                <label class="form-check-label" for="post-featured">Feature on Homepage</label>
                            </div>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Publish</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>

<script type="text/javascript">

CKEDITOR.replace('body', {
    filebrowserUploadUrl: "<?php echo e(route('ckUploadImage', ['_token' => csrf_token() ])); ?>",
    filebrowserUploadMethod: 'form'
});

$("#add-featured").click(function(){
    $('#post-image').click();
});

</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.5\resources\views/admin/blog/createPost.blade.php ENDPATH**/ ?>