

<?php $__env->startSection('content'); ?>

<div class="admin-content-padding">
    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-4">
                    <h2>Add New Item</h2>
                </div>
                <div class="col-12">
                    <form id="createProductForm" action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-title" name="title" placeholder="Product Name" value="<?php echo e(old('title')); ?>">
                        </div>
                        <div id="form-group" class="form-row">
                            <div class="col-md-4">
                                <img id="featured-thumb-image" class="col-md-4 img-responsive">
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <button type="button" id="add-featured" class="btn btn-sm btn-secondary">Add Featured Image</button>
                            <input type="file" class="d-none" id="featured-image-input" name="featured-image" onChange="document.getElementById('featured-thumb-image').src=window.URL.createObjectURL(this.files[0])">
                        </div>
                        <div id="thumbs" class="form-row">
                            
                        </div>
                        <div class="form-group">
                            <button type="button" id="add" class="btn btn-sm btn-light">Add More Images</button>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-subtitle" name="subtitle" placeholder="Product Title" value="<?php echo e(old('subtitle')); ?>">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-excerpt" name="excerpt" placeholder="Excerpt" rows="3"><?php echo e(old('excerpt')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-price" name="price" placeholder="Product Price" value="<?php echo e(old('price')); ?>">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-description" name="description" placeholder="Product Description" rows="10"><?php echo e(old('description')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control <?php $__errorArgs = ['addInfo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product-addInfo" name="addInfo" placeholder="Product Additional Information" rows="10"><?php echo e(old('addInfo')); ?></textarea>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Publish</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>

$(document).ready(function(){
    $('#product-description').summernote();
});

    var i = 0;

    $("#add").click(function(){
        i++;
        $("#thumbs").append('<div id="#product-wrapper'+ i +'" class="form-group col-md-4 thumb-product-wrapper"><img id="thumb-image'+ i +'" class="img-responsive"><a class="btn btn-danger btn-sm remove-img" type="button" onclick="this.parentElement.remove();"><span class="fa fa-times fa-lg"></span></a><input type="file" class="d-none" id="product-image'+ i +'" name="image'+ i +'" onchange=" document.getElementById(&apos;thumb-image'+i+'&apos;).src = window.URL.createObjectURL(this.files[0]) "></div>');
        $('#product-image'+ i +'').click();
    });

    $("#add-featured").click(function(){
        $('#featured-image-input').click();
    });


    </script>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.6\resources\views/admin/shop/createProduct.blade.php ENDPATH**/ ?>