

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="banner-container">
        <div class="container banner-area">
            <div class="row h-100">
                <div class="col-12 my-auto">
                    <div class="banner-title-area">
                        <h2 class="banner-title">About Us</h2>
                        <p class="banner-subtitle">Home <span><i class="fa fa-angle-right"></i></span> About Us</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="featured-twoservices" class="main-section">
        <div class="container">
            <div class="row two-service-section align-items-center">
                <div class="col-12 col-md-6 col-lg-5 order-md-2 offset-lg-1 mb-3">
                    <img class="img-responsive" src="img/symbiotic-logo.png" alt="">
                </div>
                <div class="col-12 col-md-6 order-md-1">
                    <div class="row no-gutters">
                        <div class="col-12">
                            <div class="main-section-title-side">
                                <p class="subheading">ABOUT US</p>
                                <h2 class="heading">What we are all <span>about</span></h2>
                            </div>
                        </div>
                        <div class="col-12">
                            <p class="text-justify">SymbIoTic has devoted all its work to help regions affected by any element of climate change to reduce food & water scarcity, improving resilience to natural disasters, connecting poor regions with ones that are willing to help (especially developing countries). Our work is focused to environmental monitoring parameters (water level, temperature, humidity, vibration, etc.).</p>
                        </div>
                    </div>
                </div>
                <!--
                <div class="col-12 order-md-3 mt-5">
                    <div class="row">
                        <div class="col-4">
                            <div class="mission-box">
                                <div class="mission-box-caption">
                                    <h5>Our Mission</h5>
                                    <p>Our mission is to develop economically affordable IoT devices and related network for different end users.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="mission-box">
                                <div class="mission-box-caption">
                                    <h5>Our Strategy</h5>
                                    <p>Our mission is to develop economically affordable IoT devices and related network for different end users.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="mission-box">
                                <div class="mission-box-caption">
                                    <h5>Who We Are</h5>
                                    <p>Our mission is to develop economically affordable IoT devices and related network for different end users.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                -->
            </div>
        </div>
    </div>

    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-section-title">
                        <p class="subheading">OUR SERVICES</p>
                        <h2 class="heading">Where our passion and ambition are <span>thriving</span></h2>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row no-gutters">
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="service-box">
                                <i class="fa fa-gears fa-gradient"></i>
                                <div class="service-box-caption">
                                    <h5>IoT Development</h5>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="service-box">
                            <i class="fa fa-stethoscope fa-gradient"></i>
                                <div class="service-box-caption">
                                    <h5>Solution Testing</h5>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="service-box">
                                <i class="fa fa-flask fa-gradient"></i>
                                <div class="service-box-caption">
                                    <h5>Lab Researching</h5>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="service-box">
                                <i class="fa fa-search fa-gradient"></i>
                                <div class="service-box-caption">
                                    <h5>Flood Monitoring</h5>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="service-box">
                                <i class="fa fa-leaf fa-gradient"></i>
                                <div class="service-box-caption">
                                    <h5>Vertical Farming</h5>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="service-box">
                                <i class="fa fa-life-ring fa-gradient"></i>
                                <div class="service-box-caption">
                                    <h5>Tech Support</h5>
                                    <p>Lorem ipsum dolor sit amet.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-color-video">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-color-video-title">
                        <p class="subheading">EDITORS CUT</p>
                        <h2 class="heading">Video is coming soon</h2>
                    </div>
                    <div class="play-btn-area text-center">
                        <i class="fa fa-play play-btn"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-section-title">
                        <p class="subheading">OUR TEAM</p>
                        <h2 class="heading">Devoted and goal driven <span>enthusiasts</span></h2>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="employees-box">
                                <img class="img-responsive" src="img/davor-symbiotic.jpg" alt="">
                                <div class="employees-box-caption">
                                    <h5>Davor Predavec</h5>
                                    <p>CEO</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="employees-box">
                                <img class="img-responsive" src="img/ivo-symbiotic.jpg" alt="">
                                <div class="employees-box-caption">
                                    <h5>Ivo Ljubičić</h5>
                                    <p>SW Developer</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="employees-box">
                                <img class="img-responsive" src="img/davor-symbiotic.jpg" alt="">
                                <div class="employees-box-caption">
                                    <h5>Davor Predavec</h5>
                                    <p>CEO</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="employees-box">
                                <img class="img-responsive" src="img/davor-symbiotic.jpg" alt="">
                                <div class="employees-box-caption">
                                    <h5>Davor Predavec</h5>
                                    <p>CEO</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="technologies-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="main-section-title">
                        <p class="subheading">UNDERLYING TECHNOLOGIES</p>
                        <h2 class="heading">Powered by cutting edge <span>technologies</span></h2>
                    </div>
                </div>
                <div class="col-6 col-sm-4 text-center">
                    <img class="img-responsive" src="https://le-cdn.website-editor.net/f2985373c87a4349b34f6b5f847a2e9e/dms3rep/multi/opt/I-React-Logo-ca494c6b-1440w.png" alt="">
                </div>
                <div class="col-6 col-sm-4 text-center">
                    <img class="img-responsive" src="https://d33wubrfki0l68.cloudfront.net/4c1518f0b5a0888c703d81dbd6fcd9eb5257c16d/42613/assets/img/sigfox-technology/sigfox-logo.png" alt="">
                </div>
                <div class="col-6 col-sm-4 text-center">
                    <img class="img-responsive" src="https://i0.wp.com/enterpriseiotinsights.com/wp-content/uploads/2019/07/nbiot_green_rgb.png?fit=1524%2C531&ssl=1" alt="">
                </div>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.3\resources\views/aboutUs.blade.php ENDPATH**/ ?>