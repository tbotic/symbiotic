

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="banner-container">
        <div class="container banner-area">
            <div class="row h-100">
                <div class="col-12 my-auto">
                    <div class="banner-title-area">
                        <h2 class="banner-title">Blog</h2>
                        <p class="banner-subtitle">Home <span><i class="fa fa-angle-right"></i></span> Blog</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-section">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                <?php if($posts->count()): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bl-post">
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>">
                            <img class="img-responsive" src="/images/<?php echo e($post->image); ?>" alt=""/>
                            <div class="bl-post-content">
                                <div class="bl-post-content-info row align-items-center">
                                    <small><span><i class="fa fa-clock-o"></i></span> <?php echo e($post->created_at->format('d.m.Y.')); ?></small>
                                    <small><span><i class="fa fa-user"></i></span> <?php echo e($post->user->name); ?></small>
                                </div>
                                <div class="bl-post-content-title">
                                    <h5><?php echo e($post->title); ?></h5>
                                </div>
                                <div class="blog-post-content-excerpt">
                                    <p><?php echo e($post->excerpt); ?></p>
                                </div>
                                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn-pink">Read More</a>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($posts->links()); ?>

                <?php else: ?>
                    <p class="text-center">There are no posts at this moment.</p>
                <?php endif; ?>
                </div>
                <div class="col-12 col-md-4">
                    <div class="blog-side">
                        <h5 class="blog-side-title">Latest Posts</h5>
                        <?php if($posts->count()): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('posts.show', $post->id)); ?>">
                                <div class="blog-side-articles">
                                    <p><?php echo e($post->title); ?></p>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="blog-side-articles">
                                <p>There are no posts yet.</p>
                            </div>
                            <hr>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\symbiotic\v.0.0.3\resources\views/blog/index.blade.php ENDPATH**/ ?>